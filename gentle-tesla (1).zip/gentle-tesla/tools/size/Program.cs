using System;using System.IO;using System.Linq;using System.Reflection.Metadata;using System.Reflection.Metadata.Ecma335;using System.Reflection.PortableExecutable;
class S{
 static void Main(string[] a){
  foreach(var f in a){
   using var fs=File.OpenRead(f); using var pe=new PEReader(fs);
   var r=pe.GetMetadataReader();
   Console.WriteLine("== "+Path.GetFileName(f)+"  file="+fs.Length);
   Console.WriteLine("   typerefs="+r.TypeReferences.Count+" memberrefs="+r.MemberReferences.Count+
     " customattrs="+r.CustomAttributes.Count+" asmrefs="+r.AssemblyReferences.Count+
     " modulerefs="+r.GetTableRowCount(TableIndex.ModuleRef)+" implmaps="+r.GetTableRowCount(TableIndex.ImplMap));
   int wb=0,total=0; long mn=int.MaxValue,mx=0;
   foreach(var h in r.MethodDefinitions){
     var d=r.GetMethodDefinition(h); if(d.RelativeVirtualAddress==0) continue; wb++;
     int sz=pe.GetMethodBody(d.RelativeVirtualAddress).Size; total+=sz;
     mn=Math.Min(mn,d.RelativeVirtualAddress); mx=Math.Max(mx,d.RelativeVirtualAddress); }
   Console.WriteLine("   methods_with_body="+wb+"  sum_bodybytes="+total+"  rva_span="+(mx-mn));
  }
 }
}
