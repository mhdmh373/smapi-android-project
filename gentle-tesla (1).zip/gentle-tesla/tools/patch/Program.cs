using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Mono.Cecil;
using Mono.Cecil.Cil;

/// <summary>
/// Patches the Android SMAPI build so the in-game "terminal" (the console overlay SMAPI paints
/// on top of the running game while mods load) never appears, the console-input thread never
/// spins, and the boot log list never grows.
///
/// Every patch is reversible: the untouched dll is kept next to the patched one as
/// StardewModdingAPI.original.dll
/// </summary>
class Program
{
    const string LoaderType = "StardewModdingAPI.Mobile.AndroidModLoaderManager";
    const string SCoreType = "StardewModdingAPI.Framework.SCore";

    static bool quiet = true;     // never install the on-screen console overlay
    static bool noInput = true;   // never start the Console.ReadKey thread
    static bool lowMem = true;    // never accumulate boot log lines

    static int Main(string[] args)
    {
        if (args.Length < 1)
        {
            Console.Error.WriteLine("usage: smapi-patcher <StardewModdingAPI.dll> [--show-log] [--console-input] [--keep-boot-log]");
            return 2;
        }

        string path = args[0];
        for (int i = 1; i < args.Length; i++)
        {
            if (args[i] == "--show-log") quiet = false;
            if (args[i] == "--console-input") noInput = false;
            if (args[i] == "--keep-boot-log") lowMem = false;
        }

        if (!File.Exists(path)) { Console.Error.WriteLine("not found: " + path); return 1; }

        string dir = Path.GetDirectoryName(Path.GetFullPath(path));
        string backup = Path.Combine(dir, "StardewModdingAPI.original.dll");
        if (!File.Exists(backup)) File.Copy(path, backup);

        int applied = 0;
        int dropped = 0;
        // Write to a temp file first: AssemblyDefinition.Write(path) truncates the file it is
        // still lazily reading from, which corrupts the embedded resources and throws
        // EndOfStreamException on managed-resource blobs.
        string tmp = path + ".patched.tmp";
        var resolver = new LenientResolver(dir);
        using (var asm = AssemblyDefinition.ReadAssembly(path, new ReaderParameters
        {
            AssemblyResolver = resolver
        }))
        {
            resolver.Learn(asm);
            applied += PatchQuietStart(asm);
            applied += PatchConsoleInput(asm);
            applied += PatchBootLog(asm);
            dropped += DropUnresolvableConstants(asm);
            if (applied == 0) { Console.Error.WriteLine("nothing to patch (already applied?)."); return 1; }
            asm.Write(tmp);
        }
        File.Copy(tmp, path, true);
        File.Delete(tmp);

        Console.WriteLine("patched " + applied + " method(s) in " + Path.GetFileName(path));
        if (dropped > 0)
            Console.WriteLine("cleared " + dropped + " unresolvable default value(s) — see notes in source");
        Console.WriteLine("original kept as " + Path.GetFileName(backup));
        return 0;
    }

    // Re-emitting metadata makes Cecil resolve the *type* of every default value. Nested types
    // are the one thing its lookup cannot satisfy: TypeDefinition.FullName spells them
    // "Outer/Inner", while ModuleDefinition.GetType only understands "Namespace.Name" and
    // "Namespace.Outer+Inner", so StardewValley.LightSource/LightContext always comes back
    // null and Write() dies with ResolutionException.
    //
    // Dropping the constant is the safe half-measure: the parameter *type* stays exactly as it
    // was — that signature is what Harmony matches on when it re-patches the game — and C#
    // callers always pass the argument explicitly, since "optional" is a compile-time fiction
    // and the value is baked into the call site. Only reflection and F#-style consumers, which
    // read the default straight off the Param table, would see the difference.
    static int DropUnresolvableConstants(AssemblyDefinition asm)
    {
        int n = 0;
        var seen = new List<string>();
        foreach (var module in asm.Modules)
            foreach (var type in module.Types.SelectMany(Flatten))
                foreach (var m in type.Methods)
                    foreach (var p in m.Parameters)
                    {
                        if (!p.HasConstant || p.Constant == null) continue;
                        if (IsResolvable(p.ParameterType)) continue;
                        string where = type.FullName + "." + m.Name + "(" + p.Name + ")";
                        if (!seen.Contains(where)) seen.Add(where);
                        p.HasConstant = false;
                        n++;
                    }
        foreach (var s in seen) Console.WriteLine("  const drop  : " + s);
        return n;
    }

    static bool IsResolvable(TypeReference t)
    {
        if (t == null) return true;
        if (t is TypeSpecification spec) t = spec.ElementType;
        if (t is GenericParameter) return true;   // closed over the method, not a metadata ref
        try { return t.Resolve() != null; }
        catch (AssemblyResolutionException) { return false; }
        catch (ResolutionException) { return false; }
        catch (IOException) { return false; }
        catch (NotSupportedException) { return true; }
    }

    static MethodDefinition Find(AssemblyDefinition asm, string typeName, string methodName)
    {
        foreach (var module in asm.Modules)
            foreach (var type in module.Types.SelectMany(Flatten))
            {
                if (type.FullName != typeName) continue;
                foreach (var m in type.Methods)
                    if (m.Name == methodName) return m;
            }
        return null;
    }

    static IEnumerable<TypeDefinition> Flatten(TypeDefinition t)
    {
        yield return t;
        foreach (var n in t.NestedTypes.SelectMany(Flatten)) yield return n;
    }

    // The "terminal" is not a separate app: AndroidModLoaderManager hooks the game's Draw
    // method and paints the boot log on top of the running game while mods load. Input is not
    // routed yet during that phase, which is why a tap or a volume key looks like it kills the
    // app. Both hook methods simply install/remove the Harmony patch on Game1.Draw - neutering
    // them means nothing is ever drawn and the loader itself is untouched. Mod loading progress
    // is gated on LoadStatus, not on this screen, so every mod still loads.
    static int PatchQuietStart(AssemblyDefinition asm)
    {
        if (!quiet) { Console.WriteLine("  quiet start : skipped (--show-log)"); return 0; }
        int n = 0;
        foreach (var name in new[] { "StartLoggerToScreen", "StopLoggerToScreen" })
        {
            if (NoOpMethod(asm, LoaderType, name, "  quiet start ") != 0) n++;
        }
        return n;
    }

    // OnGameInitialized spawns a background thread whose body loops on Console.ReadKey forever
    // (the compiler lowered it into SCore.<OnGameInitialized>b__62_0). There is no keyboard
    // attached to a phone, so it burns a core and never yields anything useful.
    static int PatchConsoleInput(AssemblyDefinition asm)
    {
        if (!noInput) { Console.WriteLine("  console in  : skipped (--console-input)"); return 0; }
        if (NoOpMethod(asm, SCoreType, "<OnGameInitialized>b__62_0", "  console in  ") != 0) return 1;
        return 0;
    }

    // OnLogImpl is the delegate SMAPI's monitor pushes every log line into; it appends to a
    // static List<string> that is only emptied when loading finishes. With the overlay gone
    // nothing reads that list, so dropping the lines keeps memory flat during boot.
    static int PatchBootLog(AssemblyDefinition asm)
    {
        if (!lowMem) { Console.WriteLine("  boot log    : skipped (--keep-boot-log)"); return 0; }
        if (NoOpMethod(asm, LoaderType, "OnLogImpl", "  boot log    ") != 0) return 1;
        return 0;
    }

    static int NoOpMethod(AssemblyDefinition asm, string typeName, string methodName, string label)
    {
        var m = Find(asm, typeName, methodName);
        if (m == null || m.Body == null) { Console.WriteLine(label + ": method not found, skipped"); return 0; }
        if (IsNoOp(m)) { Console.WriteLine(label + ": already patched"); return 0; }
        m.Body.Instructions.Clear();
        m.Body.Variables.Clear();
        m.Body.Instructions.Add(Instruction.Create(OpCodes.Ret));
        foreach (var h in m.Body.ExceptionHandlers.ToList()) m.Body.ExceptionHandlers.Remove(h);
        Console.WriteLine(label + ": no-op'd " + typeName.Substring(typeName.LastIndexOf('.') + 1) + "." + methodName);
        return 1;
    }

    static bool IsNoOp(MethodDefinition m)
        => m.Body.Instructions.Count <= 2 && m.Body.Instructions.Any(i => i.OpCode == OpCodes.Ret);
}

/// <summary>
/// SMAPI references the game's own assemblies (MonoGame.Framework, Microsoft.Xna.Framework, ...)
/// which are not on disk here. Cecil only needs them to re-emit metadata (e.g. a constant's
/// declaring type), so every reference is answered with a synthetic assembly that declares the
/// exact types SMAPI points at. Nothing is executed, so empty type bodies are enough.
/// </summary>
class LenientResolver : DefaultAssemblyResolver
{
    // assembly simple name -> the type full names SMAPI references from it
    readonly Dictionary<string, List<string>> _types = new Dictionary<string, List<string>>();
    readonly Dictionary<string, AssemblyDefinition> _stubs = new Dictionary<string, AssemblyDefinition>();

    public LenientResolver(string searchDir)
    {
        AddSearchDirectory(searchDir);
        AddSearchDirectory("build/smapi");
    }

    /// <summary>Walks every type/member/operand up front so the stubs exist before Cecil asks for them.</summary>
    public void Learn(AssemblyDefinition asm)
    {
        foreach (var module in asm.Modules)
        {
            foreach (var type in module.Types.SelectMany(FlattenTypes))
                LearnType(type);
        }
    }

    void LearnType(TypeDefinition t)
    {
        LearnRef(t.BaseType);
        foreach (var i in t.Interfaces) LearnRef(i.InterfaceType);
        foreach (var m in t.Methods) LearnMethod(m);
        foreach (var f in t.Fields) { LearnRef(f.FieldType); LearnAttrs(f.CustomAttributes); }
        foreach (var p in t.Properties) { LearnRef(p.PropertyType); LearnAttrs(p.CustomAttributes); }
        foreach (var e in t.Events) { LearnRef(e.EventType); LearnAttrs(e.CustomAttributes); }
        LearnAttrs(t.CustomAttributes);
        foreach (var n in t.NestedTypes) LearnType(n);
    }

    void LearnMethod(MethodDefinition m)
    {
        LearnRef(m.ReturnType);
        foreach (var p in m.Parameters) { LearnRef(p.ParameterType); LearnAttrs(p.CustomAttributes); }
        LearnAttrs(m.CustomAttributes);
        if (m.HasBody)
        {
            foreach (var v in m.Body.Variables) LearnRef(v.VariableType);
            foreach (var ins in m.Body.Instructions) LearnRef(ins.Operand as TypeReference);
        }
    }

    void LearnAttrs(IEnumerable<CustomAttribute> attrs)
    {
        foreach (var a in attrs) LearnRef(a.AttributeType);
    }

    void LearnRef(TypeReference t)
    {
        if (t == null) return;
        if (t is TypeSpecification spec) { LearnRef(spec.ElementType); return; }
        if (t is GenericInstanceType gen) { LearnRef(gen.ElementType); return; }
        var scope = t.Scope as AssemblyNameReference;
        if (scope == null) return;

        string asmName = scope.Name;
        bool known;
        try { base.Resolve(scope); return; }              // resolvable for real, nothing to stub
        catch (AssemblyResolutionException) { known = false; }
        catch (IOException) { known = false; }
        if (known) return;

        if (!_types.TryGetValue(asmName, out var list))
            _types[asmName] = list = new List<string>();
        if (!list.Contains(t.FullName)) list.Add(t.FullName);
    }

    public override AssemblyDefinition Resolve(AssemblyNameReference name)
    {
        if (_stubs.TryGetValue(name.Name, out var cached)) return cached;
        try { return base.Resolve(name); }
        catch (AssemblyResolutionException) { }
        catch (IOException) { }

        var asm = AssemblyDefinition.CreateAssembly(
            new AssemblyNameDefinition(name.Name, name.Version ?? new Version(0, 0, 0, 0)),
            name.Name + ".dll",
            ModuleKind.Dll);
        if (_types.TryGetValue(name.Name, out var list))
        {
            foreach (var full in list) AddType(asm.MainModule, full);
        }
        _stubs[name.Name] = asm;
        return asm;
    }

    /// <summary>
    /// Recreates a type so Cecil can resolve it. The first segment is a normal "Namespace.Name"
    /// type; anything after a '/' is a C# nested type, which goes in NestedTypes. Note that
    /// ModuleDefinition.GetType still cannot look a nested type up by its "Outer/Inner" full
    /// name — that is why DropUnresolvableConstants exists — but declaring it keeps the stub
    /// assembly well-formed instead of half-built.
    /// </summary>
    static void AddType(ModuleDefinition module, string full)
    {
        ICollection<TypeDefinition> parent = module.Types;
        foreach (var part in full.Split('/'))
        {
            var existing = parent.FirstOrDefault(t => t.Name == part);
            if (existing == null)
            {
                bool nested = !(ReferenceEquals(parent, module.Types) && module.Types.Count == 0) && !(parent is ModuleDefinition);
                int dot = part.LastIndexOf('.');
                existing = new TypeDefinition(
                    nested || dot == -1 ? "" : part.Substring(0, dot),
                    dot == -1 ? part : part.Substring(dot + 1),
                    nested ? TypeAttributes.NestedPublic : TypeAttributes.Public,
                    module.TypeSystem.Object);
                parent.Add(existing);
            }
            parent = existing.NestedTypes;
        }
    }

    static IEnumerable<TypeDefinition> FlattenTypes(TypeDefinition t)
    {
        yield return t;
        foreach (var n in t.NestedTypes.SelectMany(FlattenTypes)) yield return n;
    }
}
