using System;
using System.Collections.Generic;
using System.Linq;
using Mono.Cecil;

class P {
  static IEnumerable<TypeDefinition> All(TypeDefinition t) {
    yield return t;
    foreach (var n in t.NestedTypes.SelectMany(All)) yield return n;
  }
  static void Main(string[] a) {
    var asm = AssemblyDefinition.ReadAssembly(a[0]);
    string mode = a.Length > 1 ? a[1] : "meta";
    int paramsWithDefault = 0, paramsWithMarshal = 0, genericParams = 0, methodsNoBody = 0, totalInst = 0, maxStack = 0, locals = 0;
    var defaults = new SortedDictionary<string, string>();
    foreach (var m in asm.Modules) {
      Console.WriteLine("exportedTypes=" + m.ExportedTypes.Count + " resources=" + m.Resources.Count + " kind=" + m.Kind + " runtime=" + m.RuntimeVersion + " MVID=" + m.Mvid + " name=" + m.Name);
      foreach (var t in m.Types.SelectMany(All)) {
        foreach (var me in t.Methods) {
          genericParams += me.GenericParameters.Count;
          if (!me.HasBody) methodsNoBody++;
          else {
            totalInst += me.Body.Instructions.Count;
            if (me.Body.MaxStackSize > maxStack) maxStack = me.Body.MaxStackSize;
            locals += me.Body.Variables.Count;
          }
          foreach (var p in me.Parameters) {
            if (p.HasDefault) {
              paramsWithDefault++;
              defaults[p.Name + "@" + t.Name + "." + me.Name] = p.Constant == null ? "null" : p.Constant.GetType().Name;
            }
            if (p.HasMarshalInfo) paramsWithMarshal++;
          }
        }
      }
    }
    Console.WriteLine("paramsWithDefault=" + paramsWithDefault + " paramsWithMarshal=" + paramsWithMarshal +
      " genericParams=" + genericParams + " methodsNoBody=" + methodsNoBody + " totalILinst=" + totalInst +
      " maxStack=" + maxStack + " totalLocals=" + locals);
    if (mode == "defs") foreach (var kv in defaults) Console.WriteLine("  def " + kv.Key + " :: " + kv.Value);
  }
}
