using System;
using System.Linq;
using Mono.Cecil;
using Mono.Cecil.Cil;

class P {
  static void Main(string[] a) {
    var asm = AssemblyDefinition.ReadAssembly(a[0]);
    string filter = a[1];
    bool all = a.Length > 2 && a[2] == "all";
    bool il = a.Length > 2 && a[2] == "il";
    foreach (var m in asm.Modules)
    foreach (var t in m.Types.SelectMany(All)) {
      if (!t.FullName.Contains(filter, StringComparison.OrdinalIgnoreCase)) continue;
      Console.WriteLine("== " + t.FullName + (t.BaseType != null ? " : " + t.BaseType.FullName : ""));
      foreach (var f in t.Fields)
        Console.WriteLine("   F " + (f.IsPublic?"public ":f.IsPrivate?"private ":"") + (f.IsStatic?"static ":"") + f.FieldType.FullName + " " + f.Name);
      foreach (var pr in t.Properties)
        Console.WriteLine("   P " + pr.PropertyType.Name + " " + pr.Name);
      foreach (var me in t.Methods) {
        if (!il && !all && !me.IsPublic && !me.IsFamily) continue;
        Console.WriteLine("   M " + (me.IsPublic?"public ":me.IsPrivate?"private ":"") + (me.IsStatic?"static ":"") + me.ReturnType.Name + " " + me.Name + "(" +
          string.Join(", ", me.Parameters.Select(x => x.ParameterType.Name + " " + x.Name)) + ")");
        if (il && me.HasBody) {
          foreach (var ins in me.Body.Instructions)
            Console.WriteLine("        " + ins);
        }
      }
    }
  }
  static System.Collections.Generic.IEnumerable<TypeDefinition> All(TypeDefinition t) {
    yield return t;
    foreach (var n in t.NestedTypes.SelectMany(All)) yield return n;
  }
}
