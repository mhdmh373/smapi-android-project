using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace BigInventory
{
    /// <summary>
    /// Thin reflection layer over the game types. The mod is compiled without the
    /// Stardew Valley assembly, so every game member is resolved by name at runtime
    /// and cached. If Stardew changes a member in a future patch, the mod logs a clear
    /// message instead of crashing the game.
    /// </summary>
    internal static class GameAccess
    {
        private const BindingFlags PublicStatic = BindingFlags.Public | BindingFlags.Static;
        private const BindingFlags PublicInstance = BindingFlags.Public | BindingFlags.Instance;
        private const BindingFlags AnyInstance = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;

        private static Type game1Type;
        private static bool searchedForGame1;
        private static PropertyInfo activeMenuProp;

        public static Type Game1Type
        {
            get
            {
                if (!searchedForGame1)
                {
                    searchedForGame1 = true;
                    game1Type = FindGame1Type();
                }
                return game1Type;
            }
        }

        private static Type FindGame1Type()
        {
            // 1. known assembly names for 1.6 (Android/Windows) and 1.5
            foreach (string name in new[] { "Stardew Valley", "StardewValley" })
            {
                try
                {
                    var type = Type.GetType("StardewValley.Game1, " + name);
                    if (type != null)
                        return type;
                }
                catch { }
            }

            // 2. scan loaded assemblies (works whatever the game dll is called)
            foreach (var asm in AppDomain.CurrentDomain.GetAssemblies())
            {
                try
                {
                    var type = asm.GetType("StardewValley.Game1");
                    if (type != null)
                        return type;
                }
                catch { }
            }
            return null;
        }

        /// <summary>The local player (a StardewValley.Farmer), or null if there's no world loaded.</summary>
        public static object GetPlayer()
        {
            var type = Game1Type;
            if (type == null)
                return null;
            try
            {
                return type.GetProperty("player", PublicStatic)?.GetValue(null);
            }
            catch { return null; }
        }

        public static object GetActiveClickableMenu()
        {
            if (activeMenuProp == null)
                activeMenuProp = Game1Type?.GetProperty("activeClickableMenu", PublicStatic);
            try { return activeMenuProp?.GetValue(null); }
            catch { return null; }
        }

        public static bool SetActiveClickableMenu(object menu)
        {
            if (activeMenuProp == null)
                activeMenuProp = Game1Type?.GetProperty("activeClickableMenu", PublicStatic);
            if (activeMenuProp == null)
                return false;
            try
            {
                activeMenuProp.SetValue(null, menu);
                return true;
            }
            catch { return false; }
        }

        /// <summary>The player's inventory object (StardewValley.Inventories.Inventory).</summary>
        public static object GetInventory(object player)
        {
            if (player == null)
                return null;
            var prop = player.GetType().GetProperty("inventory", PublicInstance);
            if (prop != null)
                return prop.GetValue(player);
            return player.GetType().GetField("inventory", AnyInstance)?.GetValue(player);
        }

        /// <summary>The live list of items in an inventory (skips the capacity filter).</summary>
        public static IList GetItems(object inventory)
        {
            if (inventory == null)
                return null;
            var type = inventory.GetType();

            var prop = type.GetProperty("Items", PublicInstance) ?? type.GetProperty("items", AnyInstance);
            if (prop != null && typeof(IList).IsAssignableFrom(prop.PropertyType))
                return prop.GetValue(inventory) as IList;

            // pre-1.6: Inventory.GetItems() returns IList<Item>
            var getItems = type.GetMethod("getItems", new Type[0]);
            if (getItems != null && typeof(IList).IsAssignableFrom(getItems.ReturnType))
                return getItems.Invoke(inventory, null) as IList;

            var field = type.GetField("items", AnyInstance);
            return field != null && typeof(IList).IsAssignableFrom(field.FieldType)
                ? field.GetValue(inventory) as IList
                : null;
        }

        /// <summary>Reads the inventory slot capacity (1.6: Inventory.Capacity, 1.5: Farmer.InventorySize).</summary>
        public static int GetCapacity(object inventory, out string how)
        {
            how = null;
            if (inventory == null)
                return -1;
            var type = inventory.GetType();

            var prop = type.GetProperty("Capacity", PublicInstance);
            if (prop != null && prop.PropertyType == typeof(int) && prop.CanRead)
            {
                how = "Inventory.Capacity";
                return (int)prop.GetValue(inventory);
            }
            var field = type.GetField("capacity", AnyInstance);
            if (field != null && field.FieldType == typeof(int))
            {
                how = "Inventory.capacity";
                return (int)field.GetValue(inventory);
            }

            var player = GetPlayer();
            if (player != null)
            {
                var pProp = player.GetType().GetProperty("InventorySize", PublicInstance);
                if (pProp != null && pProp.PropertyType == typeof(int) && pProp.CanRead)
                {
                    how = "Farmer.InventorySize";
                    return (int)pProp.GetValue(player);
                }
            }
            return -1;
        }

        /// <summary>Writes the inventory slot capacity. Returns false if the game member wasn't found.</summary>
        public static bool SetCapacity(object inventory, int value)
        {
            if (inventory == null)
                return false;
            var type = inventory.GetType();

            var prop = type.GetProperty("Capacity", PublicInstance);
            if (prop != null && prop.PropertyType == typeof(int) && prop.CanWrite)
            {
                prop.SetValue(inventory, value);
                return true;
            }
            var field = type.GetField("capacity", AnyInstance);
            if (field != null && field.FieldType == typeof(int) && !field.IsInitOnly)
            {
                field.SetValue(inventory, value);
                return true;
            }

            var player = GetPlayer();
            if (player != null)
            {
                var pProp = player.GetType().GetProperty("InventorySize", PublicInstance);
                if (pProp != null && pProp.PropertyType == typeof(int) && pProp.CanWrite)
                {
                    pProp.SetValue(player, value);
                    return true;
                }
            }
            return false;
        }

        /// <summary>Re-opens an open InventoryMenu so the new grid is drawn immediately.</summary>
        public static bool RefreshInventoryMenu()
        {
            var menu = GetActiveClickableMenu();
            if (menu == null || menu.GetType().FullName != "StardewValley.Menus.InventoryMenu")
                return false;

            try
            {
                var ctor = menu.GetType()
                    .GetConstructors()
                    .FirstOrDefault(c =>
                    {
                        var p = c.GetParameters();
                        return p.Length == 1 && p[0].ParameterType.IsEnum;
                    });
                if (ctor == null)
                    return false;

                var category = Enum.Parse(ctor.GetParameters()[0].ParameterType, "All");
                var newMenu = ctor.Invoke(new[] { category });

                // some versions cache the row count on the menu itself
                var sizeField = newMenu.GetType().GetField("inventorySize", AnyInstance);
                int capacity;
                string how;
                var inventory = GetInventory(GetPlayer());
                if (sizeField != null && sizeField.FieldType == typeof(int) && GetCapacity(inventory, out how) > 0)
                    capacity = GetCapacity(inventory, out how);
                else
                    capacity = 0;
                if (sizeField != null && sizeField.FieldType == typeof(int) && capacity > 0)
                    sizeField.SetValue(newMenu, capacity);

                return SetActiveClickableMenu(newMenu);
            }
            catch
            {
                return false;
            }
        }

        /// <summary>Item display names, used when the backpack is shrunk (never used to delete items).</summary>
        public static IEnumerable<string> GetItemNames(IEnumerable<object> items)
        {
            var names = new List<string>();
            if (items == null)
                return names;
            foreach (var item in items)
            {
                if (item == null)
                    continue;
                try
                {
                    var name = item.GetType().GetProperty("Name", PublicInstance)?.GetValue(item) as string;
                    names.Add(name ?? item.GetType().Name);
                }
                catch { names.Add("?"); }
            }
            return names;
        }
    }
}
