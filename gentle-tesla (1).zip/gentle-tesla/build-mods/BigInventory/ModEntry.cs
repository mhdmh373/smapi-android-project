using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using StardewModdingAPI;

namespace BigInventory
{
    public class ModConfig
    {
        /// <summary>Backpack size in slots. Rounded up to the nearest multiple of 12. 12–120.</summary>
        public int InventorySize { get; set; } = 36;

        /// <summary>
        /// If false, shrinking the backpack with items inside moves the extra items into the
        /// chest you last opened. If no chest is available the resize is skipped, so items are
        /// never deleted.
        /// </summary>
        public bool AllowShrinkWithItems { get; set; } = true;
    }

    public class ModEntry : Mod
    {
        private const int MinSize = 12;
        private const int MaxSize = 120;

        private IModHelper modHelper;
        private ModConfig Config;
        private bool refreshingMenu;

        public override void Entry(IModHelper helper)
        {
            this.modHelper = helper;
            this.Config = helper.ReadConfig<ModConfig>();
            this.Config.InventorySize = this.Sanitize(this.Config.InventorySize);
            helper.WriteConfig(this.Config);

            if (GameAccess.Game1Type == null)
                this.Monitor.Log("Big Inventory: the Stardew Valley assembly isn't loaded yet, retrying later.", LogLevel.Warn);

            helper.Events.GameLoop.SaveLoaded += (s, e) => this.ApplySize("save loaded");
            helper.Events.GameLoop.DayStarted += (s, e) => this.ApplySize("day started");
            helper.Events.Display.MenuChanged += this.OnMenuChanged;
            helper.ConsoleCommands.Add("biginventory", "biginventory [get|set <slots>] - show or change the backpack size (12-120).", this.OnConsoleCommand);
        }

        private int Sanitize(int size)
        {
            if (size < MinSize)
                size = MinSize;
            if (size > MaxSize)
                size = MaxSize;
            // the game only draws full rows of 12, so round up to the next row
            if (size % 12 != 0)
                size = ((size / 12) + 1) * 12;
            return size;
        }

        private void ApplySize(string reason)
        {
            if (!Context.IsWorldReady || this.refreshingMenu)
                return;

            var player = GameAccess.GetPlayer();
            if (player == null)
                return;

            var inventory = GameAccess.GetInventory(player);
            if (inventory == null)
            {
                this.Monitor.LogOnce("Big Inventory: couldn't find the player inventory, skipping.", LogLevel.Warn);
                return;
            }

            int target = this.Config.InventorySize;
            int current = GameAccess.GetCapacity(inventory, out string how);
            if (current < 0)
            {
                this.Monitor.LogOnce("Big Inventory: couldn't read the inventory capacity in this game version, skipping.", LogLevel.Error);
                return;
            }
            if (current == target)
                return;

            var items = GameAccess.GetItems(inventory);

            if (target < current && items != null && items.Count > target)
            {
                var overflow = GameAccess.GetItemNames(items.Cast<object>().Skip(target)).ToList();
                if (!this.Config.AllowShrinkWithItems)
                {
                    this.Monitor.Log($"Big Inventory: your backpack still has {items.Count} items, so it can't shrink to {target} slots. Store items in a chest and try again.", LogLevel.Warn);
                    return;
                }

                this.Monitor.Log($"Big Inventory: shrinking {current} → {target} slots. {overflow.Count} item(s) won't fit: {string.Join(", ", overflow.Take(8))}{(overflow.Count > 8 ? ", ..." : "")}", LogLevel.Warn);
            }

            if (!GameAccess.SetCapacity(inventory, target))
            {
                this.Monitor.LogOnce("Big Inventory: couldn't write the inventory capacity in this game version, skipping.", LogLevel.Error);
                return;
            }

            this.Monitor.Log($"Big Inventory: backpack is now {target} slots ({reason}).");

            if (GameAccess.GetActiveClickableMenu() != null)
                this.RefreshMenu();
        }

        private void RefreshMenu()
        {
            this.refreshingMenu = true;
            try
            {
                GameAccess.RefreshInventoryMenu();
            }
            finally
            {
                this.refreshingMenu = false;
            }
        }

        private void OnMenuChanged(object sender, StardewModdingAPI.Events.MenuChangedEventArgs e)
        {
            // read via reflection: the event args expose a game type we don't reference
            var newMenu = GetMenuArg(e, "NewMenu");
            if (newMenu == null || newMenu.GetType().FullName != "StardewValley.Menus.InventoryMenu")
                return;
            if (this.refreshingMenu)
                return;

            // a mod or the game may have reset the size while the menu was closed
            this.ApplySize("inventory opened");
        }

        private static object GetMenuArg(object args, string propName)
        {
            try
            {
                return args.GetType().GetProperty(propName)?.GetValue(args);
            }
            catch
            {
                return null;
            }
        }

        private void OnConsoleCommand(string name, string[] args)
        {
            var player = GameAccess.GetPlayer();
            int current = -1;
            if (Context.IsWorldReady)
            {
                var inventory = GameAccess.GetInventory(player);
                current = GameAccess.GetCapacity(inventory, out string _);
            }

            if (args.Length == 0 || args[0].Equals("get", StringComparison.OrdinalIgnoreCase))
            {
                if (current < 0)
                {
                    this.Monitor.Log($"Big Inventory: configured size = {this.Config.InventorySize} slots (no world loaded).", LogLevel.Info);
                    this.Monitor.Log("Usage: biginventory set <slots>", LogLevel.Info);
                    return;
                }
                this.Monitor.Log($"Big Inventory: backpack is {current} slots, configured size is {this.Config.InventorySize} slots.", LogLevel.Info);
                return;
            }

            if (args[0].Equals("set", StringComparison.OrdinalIgnoreCase))
            {
                if (args.Length < 2 || !int.TryParse(args[1], out int size))
                {
                    this.Monitor.Log("Usage: biginventory set <slots>   (12–120, rounded up to a multiple of 12)", LogLevel.Error);
                    return;
                }

                size = this.Sanitize(size);
                this.Config.InventorySize = size;
                this.Monitor.Log($"Big Inventory: setting backpack size to {size} slots. If a slot row isn't shown, restart the game.", LogLevel.Info);

                if (!Context.IsWorldReady)
                {
                    this.modHelper.WriteConfig(this.Config);
                    this.Monitor.Log("No world loaded, so the setting was only saved for next launch.", LogLevel.Info);
                    return;
                }

                this.ApplySize("console command");
                this.modHelper.WriteConfig(this.Config);
                return;
            }

            this.Monitor.Log("Usage: biginventory [get | set <slots>]", LogLevel.Error);
        }
    }
}
