#!/data/data/com.termux/files/usr/bin/bash
# تثبيت SMAPI على أندرويد — شغّله من داخل مجلد اللعبة:
#   bash install-smapi-android.sh
set -e
GAME_DIR="${1:-$PWD}"
SRC="/sdcard/SMAPI-Android-4.3.2.5"
[ -d "$SRC" ] || { echo "خطأ: مجلد $SRC غير موجود"; exit 1; }
cd "$GAME_DIR"
echo "1/3 نسخ ملفات SMAPI إلى $(pwd)"
cp -r "$SRC"/* ./
echo "2/3 تثبيت ملف الإعدادات"
cp -f "$SRC/config.user.json" ./smapi-internal/config.user.json
echo "3/3 تجهيز مجلد المودات"
mkdir -p ./Mods
echo "تم التثبيت بنجاح."
